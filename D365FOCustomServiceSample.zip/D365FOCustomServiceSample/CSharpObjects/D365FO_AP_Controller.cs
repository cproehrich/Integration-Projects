﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net;

namespace D365FO_CSharp_Objects_Sample
{
    internal class D365FO_AP_Controller
    {
        internal static D365FO_Service_Result<D365FO_AP_POCreationResult> CreatePurchaseOrder_Entity(D365FO_AP_PurchaseOrder lot)
        {
            WebRequest request = D365FO_Common_Controller.GetWebRequest("D365FO_APServiceGroup", "D365FO_APService", "CreatePurchaseOrder_Entity", new { _lot = lot });
            string responseText = D365FO_Common_Controller.GetHttpResponseText(request);
            return JsonConvert.DeserializeObject<D365FO_Service_Result<D365FO_AP_POCreationResult>>(responseText);
        }

        internal static D365FO_Service_Result<D365FO_AP_POCreationResult> CreatePurchaseOrder_Entity2(D365FO_AP_PurchaseOrder lot)
        {
            WebRequest request = D365FO_Common_Controller.GetWebRequest("D365FO_APServiceGroup", "D365FO_APService", "CreatePurchaseOrder_Entity2", new { _lot = lot });
            string responseText = D365FO_Common_Controller.GetHttpResponseText(request);
            return JsonConvert.DeserializeObject<D365FO_Service_Result<D365FO_AP_POCreationResult>>(responseText);
        }
    }
}
