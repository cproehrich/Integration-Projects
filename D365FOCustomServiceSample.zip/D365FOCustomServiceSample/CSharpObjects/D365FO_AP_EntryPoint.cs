﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D365FO_CSharp_Objects_Sample
{
    public class D365FO_AP_EntryPoint
    {
        public static D365FO_Service_Result<D365FO_AP_POCreationResult> CreatePurchaseOrder_Entity(D365FO_AP_PurchaseOrder _lot)
        {
            D365FO_Service_Result<D365FO_AP_POCreationResult> retVal = D365FO_AP_Controller.CreatePurchaseOrder_Entity(_lot);

            // return a D365_POCreationResult
            return retVal;
        }

        public static D365FO_Service_Result<D365FO_AP_POCreationResult> CreatePurchaseOrder_Entity2(D365FO_AP_PurchaseOrder _lot)
        {
            D365FO_Service_Result<D365FO_AP_POCreationResult> retVal = D365FO_AP_Controller.CreatePurchaseOrder_Entity2(_lot);

            // return a D365_POCreationResult
            return retVal;
        }
    }
}
