﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D365FO_CSharp_Objects_Sample
{
    public class D365FO_AP_POCreationResult
    {
        public D365FO_AP_POResultLines[] poResultLines { set; get; }
    }
}
