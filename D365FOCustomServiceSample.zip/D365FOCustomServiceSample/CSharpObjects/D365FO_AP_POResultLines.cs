﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D365FO_CSharp_Objects_Sample
{
    public class D365FO_AP_POResultLines
    {
        public string PurchId { set; get; }
        public Int64 LineNumber { set; get; }
        public string ItemId { set; get; }
        public string MarkId { set; get; }
    }
}
