﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D365FO_CSharp_Objects_Sample
{
    public class D365FO_AP_PurchaseOrder
    {
        public string VendId { set; get; }

        public string PONumber { set; get; }

        public D365FO_AP_PurchaseOrderLine[] POLines { get; set; }

        public int NumPOLines { get { return POLines.Length; } }
    }
}
