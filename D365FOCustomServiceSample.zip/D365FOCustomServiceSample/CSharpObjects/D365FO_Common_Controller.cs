﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
//using Microsoft.IdentityModel.Clients.ActiveDirectory; older nuget that is replaced by Microsoft.Identity.Client
using Microsoft.Identity.Client;
using Newtonsoft.Json;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.IO;

namespace D365FO_CSharp_Objects_Sample
{
    internal static class D365FO_Common_Controller
    {
        //global settings for D365FO and Azure App Id info
        private static string aadClientAppId = "xxxxxxxf-de0c-415d-a1d6-b4ea7f66a8e6";
        private static string aadClientAppSecret = "xxxxxxxtXHJ93oLQEiK0tR1b3mAKUW6sLC1mUlVieS8=";
        private static string aadTenant = "https://login.windows.net/microsoft.com";
        private static string baseURL = "https://xxxxxxxfinopsdeveec2c152fa9c727ddevaos.cloudax.dynamics.com";
        private static string ApiUrl = "https://xxxxxxxfinopsdeveec2c152fa9c727ddevaos.cloudax.dynamics.com/api/services";

        public static string ToJson(this object objToSerialize)
        {
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(objToSerialize, Newtonsoft.Json.Formatting.Indented);
            return json;
        }

        public static WebResponse GetResponseWithoutException(this WebRequest request)
        {
            try
            {
                return request.GetResponse();
            }
            catch (WebException e)
            {
                if (e.Response == null)
                {
                    throw;
                }
                return e.Response;
            }
        }        

        private static AuthenticationResult GenerateAzureToken()
        {
            IConfidentialClientApplication app = ConfidentialClientApplicationBuilder.Create(aadClientAppId)
                    .WithClientSecret(aadClientAppSecret)
                    .WithAuthority(new Uri(aadTenant))
                    .Build();
            string[] scopes = new string[] { $"{baseURL}/.default" };

            Task<AuthenticationResult> result = app.AcquireTokenForClient(scopes).ExecuteAsync();

            return result.Result;
        }

        private static System.ServiceModel.Channels.Binding GetBinding(EndpointAddress _address)
        {
            BasicHttpBinding binding;
            binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport);
            // Set binding timeout and other configuration
            // settings
            binding.ReaderQuotas.MaxStringContentLength = int.MaxValue;
            binding.ReaderQuotas.MaxArrayLength = int.MaxValue;
            binding.ReaderQuotas.MaxNameTableCharCount = int.MaxValue;
            binding.ReceiveTimeout = TimeSpan.MaxValue;
            binding.SendTimeout = TimeSpan.MaxValue;
            binding.MaxReceivedMessageSize = int.MaxValue;
            var httpsBindingElement = binding.CreateBindingElements().OfType<HttpTransportBindingElement>().FirstOrDefault();

            if (httpsBindingElement != null)
            {
                // Largest possible is 100000, otherwise throws
                // an exception
                httpsBindingElement.MaxPendingAccepts = 10000;
            }

            var httpBindingElement = binding.CreateBindingElements().OfType<HttpTransportBindingElement>().FirstOrDefault();
            if (httpBindingElement != null)
            {
                httpBindingElement.MaxPendingAccepts = 10000;
            }

            return binding;
        }

        public static WebRequest GetWebRequest(string serviceGroup, string serviceClass, string serviceMethod, object data)
        {
            AuthenticationResult authenticationResult = GenerateAzureToken();
            string authorizationHeader = authenticationResult.CreateAuthorizationHeader();

            string url = ApiUrl + "/" + serviceGroup + "/" + serviceClass + "/" + serviceMethod;

            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            string json = JsonConvert.SerializeObject(data);
            Byte[] bodyData = encoding.GetBytes(json);

            var request = HttpWebRequest.Create(url);
            request.Headers["Authorization"] = authorizationHeader;
            request.Method = "POST";
            request.ContentLength = bodyData.Length;
            request.ContentType = @"application/json";
            using (Stream dataStream = request.GetRequestStream())
            {
                dataStream.Write(bodyData, 0, bodyData.Length);
            }

            return request;
        }

        public static string GetHttpResponseText(WebRequest request)
        {
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponseWithoutException())
            {
                // check if throttled status is 429 and if so retry using time from server response
                int retrySeconds;

                if ((int)response.StatusCode == 429)
                {
                    retrySeconds = int.Parse(response.Headers.GetValues("Retry-After").FirstOrDefault());

                    Thread.Sleep(TimeSpan.FromSeconds(retrySeconds));

                    // retry attempt
                    using (HttpWebResponse retryResponse = (HttpWebResponse)request.GetResponseWithoutException())
                    {
                        using (Stream responseStream = retryResponse.GetResponseStream())
                        {
                            using (StreamReader streamReader = new StreamReader(responseStream))
                            {
                                string responseString = streamReader.ReadToEnd();
                                return responseString;
                            }
                        }
                    }
                }

                if ((int)response.StatusCode == 500)
                {
                    Console.WriteLine("internal server error 500 in GetHttpResponseText method");

                    using (Stream responseStream = response.GetResponseStream())
                    {
                        using (StreamReader streamReader = new StreamReader(responseStream))
                        {
                            string responseString = streamReader.ReadToEnd();
                            return responseString;
                        }
                    }

                }

                else
                {
                    using (Stream responseStream = response.GetResponseStream())
                    {
                        using (StreamReader streamReader = new StreamReader(responseStream))
                        {
                            string responseString = streamReader.ReadToEnd();
                            return responseString;
                        }
                    }
                }
            }
        }        
    }
}
