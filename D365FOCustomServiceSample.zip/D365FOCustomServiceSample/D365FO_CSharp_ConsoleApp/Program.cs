﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using D365FO_CSharp_Objects_Sample;

namespace D365FO_CSharp_ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This console app will create two PO's via Custom services for D365FO.");

            // Create two PO Headers using D365FO_AP_PurchaseOrder
            D365FO_AP_PurchaseOrder _lot = new D365FO_AP_PurchaseOrder();
            _lot.PONumber = "CPRTestPO-001";
            _lot.VendId = "1001";

            D365FO_AP_PurchaseOrder _lot2 = new D365FO_AP_PurchaseOrder();
            _lot2.PONumber = "CPRTestPO-002";
            _lot2.VendId = "1001";

            // PO 1 - 2 Lines
            D365FO_AP_PurchaseOrderLine[] poLines = new D365FO_AP_PurchaseOrderLine[2];

            D365FO_AP_PurchaseOrderLine poLine1 = new D365FO_AP_PurchaseOrderLine();
            poLine1.PONumber = _lot.PONumber;
            poLine1.SiteId = "1";
            poLine1.InventItemId = "A0001";
            poLine1.LocationId = "11";
            poLine1.Qty = 1;
            poLine1.DefaultDimensionString = "002--024"; // BusinessUnit-CostCenter-Department
            poLines[0] = poLine1;

            D365FO_AP_PurchaseOrderLine poLine2 = new D365FO_AP_PurchaseOrderLine();
            poLine2.PONumber = _lot.PONumber;
            poLine2.InventItemId = "A0001";
            poLine2.SiteId = "1";
            poLine2.LocationId = "11";
            poLine2.Qty = 2;
            poLines[1] = poLine2;

            _lot.POLines = poLines;

            // PO 2 - 2 Lines
            D365FO_AP_PurchaseOrderLine[] po2Lines = new D365FO_AP_PurchaseOrderLine[2];

            D365FO_AP_PurchaseOrderLine po2Line1 = new D365FO_AP_PurchaseOrderLine();
            po2Line1.PONumber = _lot2.PONumber;
            po2Line1.SiteId = "1";
            po2Line1.InventItemId = "A0001";
            po2Line1.LocationId = "11";
            po2Line1.Qty = 1;
            po2Line1.DefaultDimensionString = "002--024"; // BusinessUnit-CostCenter-Department
            po2Lines[0] = po2Line1;

            D365FO_AP_PurchaseOrderLine po2Line2 = new D365FO_AP_PurchaseOrderLine();
            po2Line2.PONumber = _lot2.PONumber;
            po2Line2.InventItemId = "A0001";
            po2Line2.SiteId = "1";
            po2Line2.LocationId = "11";
            po2Line2.Qty = 2;
            po2Lines[1] = po2Line2;

            _lot2.POLines = po2Lines;

            Console.WriteLine("Calling the CreatePurchaseOrder_Entity C# method...");
            D365FO_Service_Result<D365FO_AP_POCreationResult> result = D365FO_AP_EntryPoint.CreatePurchaseOrder_Entity(_lot);

            Console.WriteLine(result.Message);
            if (result.Success)
            {
                Console.WriteLine("Purchase order: " + result.Data.poResultLines[0].PurchId);
                Console.WriteLine("LineNumber: " + result.Data.poResultLines[0].LineNumber.ToString() + " Item: " + result.Data.poResultLines[0].ItemId + " InventTransId: " + result.Data.poResultLines[0].MarkId);
                Console.WriteLine("LineNumber: " + result.Data.poResultLines[1].LineNumber.ToString() + " Item: " + result.Data.poResultLines[1].ItemId + " InventTransId: " + result.Data.poResultLines[1].MarkId);
            }

            Console.WriteLine("Calling the CreatePurchaseOrder_Entity2 C# method...");
            D365FO_Service_Result<D365FO_AP_POCreationResult> result2 = D365FO_AP_EntryPoint.CreatePurchaseOrder_Entity2(_lot2);

            Console.WriteLine(result2.Message);
            if (result2.Success)
            {
                Console.WriteLine("Purchase order: " + result2.Data.poResultLines[0].PurchId);
                Console.WriteLine("LineNumber: " + result2.Data.poResultLines[0].LineNumber.ToString() + " Item: " + result2.Data.poResultLines[0].ItemId + " InventTransId: " + result2.Data.poResultLines[0].MarkId);
                Console.WriteLine("LineNumber: " + result2.Data.poResultLines[1].LineNumber.ToString() + " Item: " + result2.Data.poResultLines[1].ItemId + " InventTransId: " + result2.Data.poResultLines[1].MarkId);
            }

            Console.ReadLine();
        }
    }
}
